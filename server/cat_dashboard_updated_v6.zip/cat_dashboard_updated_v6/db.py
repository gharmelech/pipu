import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path

import config


def _connect():
    Path(config.DB_FILE).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(config.DB_FILE), timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('PRAGMA synchronous=NORMAL')
    conn.execute('PRAGMA foreign_keys=ON')
    return conn


@contextmanager
def connect():
    conn = _connect()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db():
    with connect() as conn:
        conn.executescript(
            '''
            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_hash TEXT NOT NULL UNIQUE,
                ts TEXT NOT NULL,
                raw_cat_id TEXT,
                candidate_cat TEXT,
                cat TEXT,
                event_kind TEXT,
                cat_weight REAL,
                deposit_weight REAL,
                duration_sec REAL,
                cat_weight_outlier INTEGER NOT NULL DEFAULT 0,
                deposit_weight_outlier INTEGER NOT NULL DEFAULT 0,
                attribution_status TEXT NOT NULL,
                reject_reason TEXT
            );

            CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts);
            CREATE INDEX IF NOT EXISTS idx_events_cat_ts ON events(cat, ts);
            CREATE INDEX IF NOT EXISTS idx_events_candidate_ts ON events(candidate_cat, ts);
            CREATE INDEX IF NOT EXISTS idx_events_kind_ts ON events(event_kind, ts);

            CREATE TABLE IF NOT EXISTS latest_traces (
                cat TEXT NOT NULL,
                event_kind TEXT NOT NULL,
                ts TEXT NOT NULL,
                samples_json TEXT NOT NULL,
                marker_times_json TEXT NOT NULL,
                PRIMARY KEY(cat, event_kind)
            );

            CREATE TABLE IF NOT EXISTS cat_state (
                cat TEXT PRIMARY KEY,
                bootstrap_weight REAL NOT NULL,
                adaptive_weight REAL NOT NULL,
                stats_start TEXT,
                updated_at TEXT
            );

            CREATE TABLE IF NOT EXISTS log_state (
                id INTEGER PRIMARY KEY CHECK(id = 1),
                device INTEGER,
                inode INTEGER,
                offset INTEGER NOT NULL DEFAULT 0,
                size INTEGER NOT NULL DEFAULT 0,
                generation INTEGER NOT NULL DEFAULT 0,
                last_sync TEXT,
                anchor_start INTEGER,
                anchor_hash TEXT
            );

            CREATE TABLE IF NOT EXISTS reset_audit (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts TEXT NOT NULL,
                cat TEXT NOT NULL,
                mode TEXT NOT NULL,
                requested_start TEXT,
                effective_start TEXT,
                note TEXT
            );
            '''
        )

        # Lightweight migrations for databases created by an earlier dashboard version.
        cols = {r['name'] for r in conn.execute('PRAGMA table_info(log_state)').fetchall()}
        if 'anchor_start' not in cols:
            conn.execute('ALTER TABLE log_state ADD COLUMN anchor_start INTEGER')
        if 'anchor_hash' not in cols:
            conn.execute('ALTER TABLE log_state ADD COLUMN anchor_hash TEXT')

        for cat in config.CATS:
            bootstrap = float(config.BOOTSTRAP_WEIGHT_G[cat])
            conn.execute(
                '''
                INSERT INTO cat_state(cat, bootstrap_weight, adaptive_weight)
                VALUES (?, ?, ?)
                ON CONFLICT(cat) DO NOTHING
                ''',
                (cat, bootstrap, bootstrap),
            )

        conn.execute(
            'INSERT INTO log_state(id, offset, size, generation) VALUES (1, 0, 0, 0) '
            'ON CONFLICT(id) DO NOTHING'
        )


def json_dumps(value):
    return json.dumps(value, separators=(',', ':'))
