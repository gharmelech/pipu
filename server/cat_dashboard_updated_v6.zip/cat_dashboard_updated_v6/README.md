# Cat Health Dashboard

A local Flask dashboard for the cat litter-box log.

## Design

- Raw events continue to be appended to the text log.
- Compact event summaries and statistical state are persisted in SQLite (`data/cat_stats.db`).
- Full historical sample arrays are **not** duplicated into SQLite.
- Only the latest pee and poo waveform per cat are kept in SQLite for the event plots.
- A SHA-256 event fingerprint prevents duplicate counting if the log is rescanned.
- Log truncation/replacement never automatically clears statistics. The parser detects it and resumes from the new file while preserving SQLite state.
- Missing `Cat ID` means candidate `Pini`, but attribution only succeeds if body weight is inside Pini's adaptive weight gate.
- The same body-weight attribution gate is applied to all cats.
- `Jessie` in old logs is normalized to the preferred spelling `Jessy`.
- `-1000` samples are excluded. On latest-event plots they become vertical markers 4 seconds earlier than their original sample position.

## Before first run

Edit `config.py`:

1. Set `LOG_FILE` to the exact existing log path.
2. Set accurate `BOOTSTRAP_WEIGHT_G` values for Terry, Katani, Jessy and Pini.
3. Verify `EVENT_TYPE_MAP`. The starter project assumes Type 1 = pee and Type 2 = poo. Reverse it if your logger uses the opposite meaning.
4. Tune attribution and trend tolerances if desired.

## Run locally

```bash
./setup.sh
.venv/bin/python app.py
```

Then open `http://PI_ADDRESS:5000/`.

## HTTP endpoints

The replacement server keeps the existing logger contract while giving the pages clearer URLs:

- `GET /` — new health dashboard.
- `POST /log` — logger endpoint. Every JSON object is appended to the raw log and processed into the statistics DB.
- `GET /view?refresh=5&count=100` — raw log viewer, newest line first. `refresh=0` disables auto-refresh.
- `GET /hist` — redirects to the new dashboard so old bookmarks still work.
- `POST /api/log` — optional API alias of `/log`.

The `/log` endpoint writes the existing text format:

```text
YYYY-MM-DD HH:MM:SS {'Type': '2', ...}
```

This build is intended to replace the old Flask log server on port 5000. Stop the old service before starting this one, because only one process can listen on the port. Back up the old application and raw log first; the new application appends to the configured `LOG_FILE` rather than replacing it.

Viewer defaults and safety limits are configurable in `config.py` with `VIEWER_DEFAULT_REFRESH_SEC`, `VIEWER_DEFAULT_COUNT`, `VIEWER_MAX_REFRESH_SEC`, and `VIEWER_MAX_COUNT`.

## systemd

Copy `cat-dashboard.service.example`, replacing:

- `REPLACE_WITH_PI_USER`
- `REPLACE_WITH_PROJECT_DIR`

Then:

```bash
sudo cp cat-dashboard.service.example /etc/systemd/system/cat-dashboard.service
sudo systemctl daemon-reload
sudo systemctl enable --now cat-dashboard.service
sudo systemctl status cat-dashboard.service
```

## Statistics reset

Each cat page has **Zero Statistics**. It requires typing `yes`, then offers:

- beginning of available log,
- a specific date,
- now.

The cat's compact DB history is cleared. For rebuild modes, raw log entries are reparsed from the effective start date. If the chosen date predates the current log, the earliest available log timestamp is used.

## Important

This is a monitoring dashboard, not a veterinary diagnostic system. Traffic-light thresholds are user-configurable statistical alerts, not medical thresholds.
