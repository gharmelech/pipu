#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"
python3 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
mkdir -p data

echo
echo "Setup complete."
echo "1) Edit config.py and set LOG_FILE + bootstrap cat weights."
echo "2) Check EVENT_TYPE_MAP (Type 1/2 pee/poo mapping)."
echo "3) Run: .venv/bin/python app.py"
echo "4) Open: http://<pi-ip>:5000/"
