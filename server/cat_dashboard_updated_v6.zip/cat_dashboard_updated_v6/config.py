from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

# Change these two paths for your Pi.
LOG_FILE = Path('/home/pi/catlog.txt')
DB_FILE = BASE_DIR / 'data' / 'cat_stats.db'

CATS = ['Terry', 'Katani', 'Jessy', 'Pini']

# Known spellings/aliases. Preferred display spelling is Jessy.
CAT_ALIASES = {
    'terry': 'Terry',
    'katani': 'Katani',
    'jessy': 'Jessy',
    'jessie': 'Jessy',
    'pini': 'Pini',
    'pinni': 'Pini',
}

# Event Type mapping used by the logger.
EVENT_TYPE_MAP = {
    '1': 'pee',
    '2': 'poo',
}

# Bootstrap weights are only used until each cat has enough accepted history.
# Initial known weights; the attribution baseline adapts from accepted history.
BOOTSTRAP_WEIGHT_G = {
    'Terry': 7900,
    'Katani': 3500,
    'Jessy': 3600,
    'Pini': 4200,
}

# An event is only attributed to the candidate cat if its body weight is within
# this adaptive gate around that cat's robust expected weight.
ATTRIBUTION_WEIGHT_TOLERANCE_PERCENT = 12.0
ATTRIBUTION_WEIGHT_TOLERANCE_MIN_G = 350.0
ADAPTIVE_WEIGHT_LOOKBACK_DAYS = 30
ADAPTIVE_WEIGHT_MAX_POINTS = 50

# Body-weight trend is considered unchanged inside +/- 2% by default.
TREND_RECENT_DAYS = 7
TREND_BASELINE_DAYS = 30
FULL_STATS_DAYS = 30

# Minimum valid observations required before a trend is considered mature.
MIN_POINTS = {
    'cat_weight': 10,
    'pee_count': 10,
    'poo_count': 8,
    'pee_weight': 10,
    'poo_weight': 8,
}

# Traffic-light thresholds are percentage changes versus the baseline.
# stable: no directional concern; warning: yellow; critical: red.
TREND_THRESHOLDS = {
    'cat_weight': {'stable': 2.0, 'warning': 5.0, 'critical': 10.0},
    'pee_count': {'stable': 10.0, 'warning': 25.0, 'critical': 50.0},
    'poo_count': {'stable': 10.0, 'warning': 25.0, 'critical': 50.0},
    'pee_weight': {'stable': 10.0, 'warning': 25.0, 'critical': 50.0},
    'poo_weight': {'stable': 10.0, 'warning': 25.0, 'critical': 50.0},
}

# Deposit weights are often signed by the sensor. For a physical deposit mass,
# absolute values are usually what you want. Set False if your values are already positive.
DEPOSIT_WEIGHT_ABSOLUTE = True

SAMPLE_INTERVAL_SEC = 0.010
DEPOSIT_TIME_OFFSET_SEC = 10.0
MARKER_VALUE = -1000
MARKER_SHIFT_SEC = 4.0

# Outlier settings. These only affect statistical inclusion; raw log data is untouched.
OUTLIER_MIN_POINTS = 7
OUTLIER_MAD_Z = 3.5
OUTLIER_ZERO_MAD_PERCENT = 4.0

# Dashboard API syncs newly appended log data at most this often.
LOG_SYNC_MIN_INTERVAL_SEC = 2.0

HOST = '0.0.0.0'
PORT = 5000
DEBUG = False

# Raw log viewer defaults. Example: /view?refresh=5&count=200
# refresh=0 disables browser auto-refresh.
VIEWER_DEFAULT_REFRESH_SEC = 5
VIEWER_DEFAULT_COUNT = 100
VIEWER_MAX_REFRESH_SEC = 3600
VIEWER_MAX_COUNT = 10000
