from collections import deque

from flask import Flask, jsonify, redirect, render_template, request, url_for

import analytics
import config
import db

app = Flask(__name__)


def api_error(message, status=400):
    return jsonify({'ok': False, 'error': message}), status


def _bounded_int_arg(name, default, minimum, maximum):
    """Read an integer query argument and clamp it to a safe range."""
    raw = request.args.get(name, default)
    try:
        value = int(raw)
    except (TypeError, ValueError):
        value = default
    return max(minimum, min(maximum, value))


def _tail_lines(path, count):
    """Return up to count raw log lines, newest first, without loading the whole log."""
    if count <= 0 or not path.exists():
        return []

    with path.open('r', encoding='utf-8', errors='replace') as f:
        lines = deque(f, maxlen=count)

    return [line.rstrip('\r\n') for line in reversed(lines)]


@app.get('/')
def root():
    return render_template('index.html')


@app.post('/log')
def log_event():
    """Existing device-facing logger endpoint: every JSON object is appended to the raw log."""
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        return api_error('Expected a JSON object')

    ts = analytics.append_log_event(payload)
    return jsonify({'ok': True, 'timestamp': analytics.dt_to_str(ts)})


# Keep the API alias used by the dashboard project itself / future integrations.
@app.post('/api/log')
def api_log():
    return log_event()


@app.get('/view')
def view_log():
    """Reverse-order raw log viewer.

    Query parameters:
      refresh: seconds between browser refreshes; 0 disables auto-refresh.
      count:   maximum number of newest log lines to show.
    """
    refresh = _bounded_int_arg(
        'refresh',
        config.VIEWER_DEFAULT_REFRESH_SEC,
        0,
        config.VIEWER_MAX_REFRESH_SEC,
    )
    count = _bounded_int_arg(
        'count',
        config.VIEWER_DEFAULT_COUNT,
        1,
        config.VIEWER_MAX_COUNT,
    )

    lines = _tail_lines(config.LOG_FILE, count)
    return render_template(
        'view.html',
        lines=lines,
        refresh=refresh,
        count=count,
        log_path=str(config.LOG_FILE),
    )


# Old first-generation statistics URL: keep bookmarks working.
@app.get('/hist')
def legacy_hist():
    return redirect(url_for('root'), code=302)


@app.get('/cat/<cat>')
def cat_page(cat):
    if cat not in config.CATS:
        return 'Unknown cat', 404
    return render_template('cat.html', cat=cat)


@app.get('/api/dashboard')
def api_dashboard():
    return jsonify(analytics.dashboard_summary())


@app.get('/api/cat/<cat>')
def api_cat(cat):
    if cat not in config.CATS:
        return api_error('Unknown cat', 404)
    range_name = request.args.get('range', 'week')
    if range_name not in ('24h', 'week', 'month', 'max'):
        return api_error('range must be 24h, week, month or max')
    return jsonify(analytics.cat_series(cat, range_name))


@app.post('/api/cat/<cat>/zero')
def api_zero_cat(cat):
    if cat not in config.CATS:
        return api_error('Unknown cat', 404)
    payload = request.get_json(silent=True) or {}
    if str(payload.get('confirm', '')).strip().lower() != 'yes':
        return api_error('Confirmation text must be yes')
    try:
        result = analytics.rebuild_cat(
            cat,
            payload.get('mode'),
            payload.get('start_date'),
        )
    except ValueError as exc:
        return api_error(str(exc))
    return jsonify({'ok': True, 'result': result})


@app.get('/api/config/public')
def api_public_config():
    return jsonify({
        'cats': config.CATS,
        'full_stats_days': config.FULL_STATS_DAYS,
        'event_type_map': config.EVENT_TYPE_MAP,
    })


if __name__ == '__main__':
    db.init_db()
    analytics.sync_log(force=True)
    app.run(host=config.HOST, port=config.PORT, debug=config.DEBUG, threaded=True)
