const cat = document.body.dataset.cat;
let selectedRange = 'week';

const CHART_COLORS = {
  // Combined pee/poo statistic charts only:
  pee: '#f0bd4b',
  poo: '#78a6ff',

  // Individual event waveforms stay blue regardless of event type.
  eventTrace: '#78a6ff',
  weight: '#78a6ff'
};

function setupCanvas(canvas, height = 300) {
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  canvas.width = Math.max(600, Math.floor(rect.width * dpr));
  canvas.height = Math.floor(height * dpr);
  const ctx = canvas.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  const w = canvas.width / dpr;
  const h = canvas.height / dpr;
  ctx.clearRect(0, 0, w, h);
  return {ctx, w, h};
}

function drawMultiLine(canvas, labels, datasets, opts = {}) {
  const {ctx, w, h} = setupCanvas(canvas);
  const showLegend = opts.showLegend !== false;
  const pad = {l:54, r:18, t:showLegend ? 38 : 18, b:42};

  const finite = datasets.flatMap(ds =>
    ds.values
      .filter(v => v !== null && Number.isFinite(Number(v)))
      .map(Number)
  );

  if (!finite.length) {
    ctx.fillStyle = '#95a2bd';
    ctx.font = '14px sans-serif';
    ctx.fillText('No data in this range', 20, 40);
    return;
  }

  let min = Math.min(...finite);
  let max = Math.max(...finite);
  if (opts.zeroBase) min = Math.min(0, min);
  if (min === max) {
    if (min === 0) max = 1;
    else { min -= 1; max += 1; }
  }
  const span = max - min;
  if (!opts.zeroBase) min -= span * .1;
  max += span * .1;

  ctx.strokeStyle = '#2b3650';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(pad.l, pad.t);
  ctx.lineTo(pad.l, h - pad.b);
  ctx.lineTo(w - pad.r, h - pad.b);
  ctx.stroke();

  ctx.fillStyle = '#95a2bd';
  ctx.font = '11px sans-serif';
  for (let i = 0; i <= 4; i++) {
    const y = pad.t + (h - pad.t - pad.b) * i / 4;
    const v = max - (max - min) * i / 4;
    ctx.fillText(v.toFixed(opts.decimals ?? 1), 4, y + 4);
    ctx.strokeStyle = 'rgba(43,54,80,.55)';
    ctx.beginPath();
    ctx.moveTo(pad.l, y);
    ctx.lineTo(w - pad.r, y);
    ctx.stroke();
  }

  const xFor = i => labels.length <= 1
    ? (pad.l + w - pad.r) / 2
    : pad.l + (w - pad.l - pad.r) * i / (labels.length - 1);
  const yFor = v => pad.t + (max - Number(v)) / (max - min) * (h - pad.t - pad.b);

  datasets.forEach(ds => {
    ctx.strokeStyle = ds.color;
    ctx.lineWidth = 2;
    ctx.setLineDash([]);
    ctx.beginPath();
    let started = false;
    ds.values.forEach((v, i) => {
      if (v === null || !Number.isFinite(Number(v))) {
        // Counts should break at missing data. For event-weight averages we
        // connect the valid measurement buckets across empty hours/days.
        if (!ds.connectGaps) started = false;
        return;
      }
      const x = xFor(i);
      const y = yFor(v);
      if (!started) {
        ctx.moveTo(x, y);
        started = true;
      } else {
        ctx.lineTo(x, y);
      }
    });
    ctx.stroke();

    if (ds.drawPoints) {
      ctx.fillStyle = ds.color;
      ds.values.forEach((v, i) => {
        if (v === null || !Number.isFinite(Number(v))) return;
        const x = xFor(i);
        const y = yFor(v);
        ctx.beginPath();
        ctx.arc(x, y, 2.8, 0, Math.PI * 2);
        ctx.fill();
      });
    }
  });

  // Legend
  if (showLegend) {
    let legendX = pad.l;
    const legendY = 17;
    ctx.font = '12px sans-serif';
    datasets.forEach(ds => {
      ctx.strokeStyle = ds.color;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(legendX, legendY);
      ctx.lineTo(legendX + 18, legendY);
      ctx.stroke();
      ctx.fillStyle = '#eef3ff';
      ctx.fillText(ds.label, legendX + 24, legendY + 4);
      legendX += 24 + ctx.measureText(ds.label).width + 24;
    });
  }

  const ticks = Math.min(6, labels.length);
  for (let j = 0; j < ticks; j++) {
    const i = Math.round((labels.length - 1) * j / Math.max(1, ticks - 1));
    const text = labels[i] || '';
    ctx.fillStyle = '#95a2bd';
    ctx.save();
    ctx.translate(xFor(i), h - 10);
    ctx.rotate(-0.35);
    ctx.fillText(text.slice(5), -18, 0);
    ctx.restore();
  }
}

function drawLine(canvas, labels, values, opts = {}) {
  drawMultiLine(canvas, labels, [{
    label: opts.label || '',
    values,
    color: opts.color || CHART_COLORS.weight
  }], {...opts, hideLegend: true});
}

const traceViews = new WeakMap();

function traceKey(trace) {
  if (!trace || !trace.x || !trace.x.length) return 'empty';
  const xs = trace.x;
  return `${trace.ts || ''}|${xs.length}|${xs[0]}|${xs[xs.length - 1]}`;
}

function clampTraceView(state, minX, maxX) {
  const fullSpan = state.fullMaxX - state.fullMinX;
  if (!(fullSpan > 0)) return [state.fullMinX, state.fullMaxX];

  const minSpan = Math.max(fullSpan / 500, 0.05);
  let span = Math.max(minSpan, Math.min(maxX - minX, fullSpan));
  let lo = minX;
  let hi = lo + span;

  if (lo < state.fullMinX) {
    lo = state.fullMinX;
    hi = lo + span;
  }
  if (hi > state.fullMaxX) {
    hi = state.fullMaxX;
    lo = hi - span;
  }
  return [lo, hi];
}

function setTraceView(canvas, minX, maxX) {
  const state = traceViews.get(canvas);
  if (!state) return;
  [state.viewMinX, state.viewMaxX] = clampTraceView(state, minX, maxX);
  drawTrace(canvas, state.trace, state.eventType);
}

function resetTraceView(canvas) {
  const state = traceViews.get(canvas);
  if (!state) return;
  state.viewMinX = state.fullMinX;
  state.viewMaxX = state.fullMaxX;
  drawTrace(canvas, state.trace, state.eventType);
}

function zoomTrace(canvas, factor, anchorRatio = 0.5) {
  const state = traceViews.get(canvas);
  if (!state) return;
  const span = state.viewMaxX - state.viewMinX;
  const anchor = state.viewMinX + span * Math.max(0, Math.min(1, anchorRatio));
  const newSpan = span * factor;
  const minX = anchor - newSpan * anchorRatio;
  const maxX = minX + newSpan;
  setTraceView(canvas, minX, maxX);
}

function ensureTraceInteraction(canvas) {
  if (canvas.dataset.traceZoomReady === '1') return;
  canvas.dataset.traceZoomReady = '1';

  const geometry = () => {
    const rect = canvas.getBoundingClientRect();
    const padLeft = 54;
    const padRight = 18;
    return {
      rect,
      padLeft,
      plotWidth: Math.max(1, rect.width - padLeft - padRight)
    };
  };

  const ratioForClientX = clientX => {
    const {rect, padLeft, plotWidth} = geometry();
    return Math.max(0, Math.min(1, (clientX - rect.left - padLeft) / plotWidth));
  };

  const beginSinglePointerPan = (state, clientX) => {
    state.dragging = true;
    state.dragStartX = clientX;
    state.dragStartMin = state.viewMinX;
    state.dragStartMax = state.viewMaxX;
    canvas.classList.add('dragging');
  };

  const beginPinch = state => {
    const points = [...state.touchPointers.values()];
    if (points.length < 2) return;

    const a = points[0];
    const b = points[1];
    const distance = Math.hypot(b.x - a.x, b.y - a.y);
    const midX = (a.x + b.x) / 2;
    const ratio = ratioForClientX(midX);
    const span = state.viewMaxX - state.viewMinX;

    state.pinching = true;
    state.dragging = false;
    state.pinchStartDistance = Math.max(10, distance);
    state.pinchStartSpan = span;
    state.pinchAnchorTime = state.viewMinX + span * ratio;
    canvas.classList.add('dragging');
  };

  canvas.addEventListener('wheel', event => {
    const state = traceViews.get(canvas);
    if (!state) return;
    event.preventDefault();
    zoomTrace(canvas, event.deltaY < 0 ? 0.78 : 1.28, ratioForClientX(event.clientX));
  }, {passive:false});

  canvas.addEventListener('pointerdown', event => {
    const state = traceViews.get(canvas);
    if (!state) return;

    const {rect} = geometry();
    if (event.clientX < rect.left + 54 || event.clientX > rect.right - 18) return;

    if (event.pointerType === 'touch') {
      if (!state.touchPointers) state.touchPointers = new Map();
      state.touchPointers.set(event.pointerId, {x:event.clientX, y:event.clientY});

      try { canvas.setPointerCapture(event.pointerId); } catch (_) {}

      if (state.touchPointers.size >= 2) {
        beginPinch(state);
      } else {
        beginSinglePointerPan(state, event.clientX);
      }
      return;
    }

    if (event.button !== 0) return;
    beginSinglePointerPan(state, event.clientX);
    try { canvas.setPointerCapture(event.pointerId); } catch (_) {}
  });

  canvas.addEventListener('pointermove', event => {
    const state = traceViews.get(canvas);
    if (!state) return;

    if (event.pointerType === 'touch' && state.touchPointers?.has(event.pointerId)) {
      state.touchPointers.set(event.pointerId, {x:event.clientX, y:event.clientY});

      if (state.pinching && state.touchPointers.size >= 2) {
        if (event.cancelable) event.preventDefault();

        const points = [...state.touchPointers.values()];
        const a = points[0];
        const b = points[1];
        const distance = Math.max(10, Math.hypot(b.x - a.x, b.y - a.y));
        const midX = (a.x + b.x) / 2;
        const currentRatio = ratioForClientX(midX);
        const newSpan = state.pinchStartSpan * state.pinchStartDistance / distance;
        const minX = state.pinchAnchorTime - newSpan * currentRatio;
        const maxX = minX + newSpan;

        [state.viewMinX, state.viewMaxX] = clampTraceView(state, minX, maxX);
        drawTrace(canvas, state.trace, state.eventType);
        return;
      }
    }

    if (!state.dragging || state.pinching) return;
    const {plotWidth} = geometry();
    const span = state.dragStartMax - state.dragStartMin;
    const shift = -(event.clientX - state.dragStartX) / plotWidth * span;
    const [lo, hi] = clampTraceView(state, state.dragStartMin + shift, state.dragStartMax + shift);
    state.viewMinX = lo;
    state.viewMaxX = hi;
    drawTrace(canvas, state.trace, state.eventType);
  });

  const stopPointer = event => {
    const state = traceViews.get(canvas);
    if (!state) return;

    if (event.pointerType === 'touch' && state.touchPointers) {
      state.touchPointers.delete(event.pointerId);

      if (state.pinching && state.touchPointers.size < 2) {
        state.pinching = false;

        // If one finger remains after a pinch, let it continue as a pan from
        // the current zoomed view instead of jumping back to the old drag state.
        if (state.touchPointers.size === 1) {
          const remaining = [...state.touchPointers.values()][0];
          beginSinglePointerPan(state, remaining.x);
        } else {
          state.dragging = false;
          canvas.classList.remove('dragging');
        }
      } else if (state.touchPointers.size === 0) {
        state.dragging = false;
        canvas.classList.remove('dragging');
      }
    } else {
      state.dragging = false;
      canvas.classList.remove('dragging');
    }

    try {
      if (canvas.hasPointerCapture(event.pointerId)) canvas.releasePointerCapture(event.pointerId);
    } catch (_) {}
  };

  canvas.addEventListener('pointerup', stopPointer);
  canvas.addEventListener('pointercancel', stopPointer);
  canvas.addEventListener('dblclick', () => resetTraceView(canvas));
}

function drawTrace(canvas, trace, eventType) {
  const {ctx, w, h} = setupCanvas(canvas);

  if (!trace || !trace.x || !trace.x.length) {
    traceViews.delete(canvas);
    ctx.fillStyle = '#95a2bd'; ctx.font = '14px sans-serif';
    ctx.fillText('No event trace available', 20, 40); return;
  }

  const pad = {l:54,r:18,t:18,b:42};
  const xs = trace.x.map(Number);
  const ys = trace.y.map(Number);
  const fullMinX = Math.min(...xs);
  let fullMaxX = Math.max(...xs);
  if (fullMaxX === fullMinX) fullMaxX = fullMinX + 1;

  const key = traceKey(trace);
  let state = traceViews.get(canvas);
  if (!state || state.key !== key) {
    state = {
      key,
      trace,
      eventType,
      fullMinX,
      fullMaxX,
      viewMinX: fullMinX,
      viewMaxX: fullMaxX,
      dragging: false,
      pinching: false,
      touchPointers: new Map()
    };
    traceViews.set(canvas, state);
  } else {
    state.trace = trace;
    state.eventType = eventType;
    state.fullMinX = fullMinX;
    state.fullMaxX = fullMaxX;
    [state.viewMinX, state.viewMaxX] = clampTraceView(state, state.viewMinX, state.viewMaxX);
  }
  ensureTraceInteraction(canvas);

  const minX = state.viewMinX;
  const maxX = state.viewMaxX;
  const visibleYs = ys.filter((y, i) => xs[i] >= minX && xs[i] <= maxX && Number.isFinite(y));
  const ySource = visibleYs.length ? visibleYs : ys.filter(Number.isFinite);
  let minY = Math.min(...ySource), maxY = Math.max(...ySource);
  if (maxY === minY) { minY -= 1; maxY += 1; }
  const ySpan = maxY - minY; minY -= ySpan*.08; maxY += ySpan*.08;

  const xFor = x => pad.l + (x-minX)/(maxX-minX)*(w-pad.l-pad.r);
  const yFor = y => pad.t + (maxY-y)/(maxY-minY)*(h-pad.t-pad.b);

  ctx.strokeStyle='#2b3650'; ctx.lineWidth=1;
  ctx.beginPath(); ctx.moveTo(pad.l,pad.t); ctx.lineTo(pad.l,h-pad.b); ctx.lineTo(w-pad.r,h-pad.b); ctx.stroke();
  ctx.fillStyle='#95a2bd'; ctx.font='11px sans-serif';
  for (let i=0;i<=4;i++) {
    const y=pad.t+(h-pad.t-pad.b)*i/4;
    const value=maxY-(maxY-minY)*i/4;
    ctx.fillText(value.toFixed(0),4,y+4);
    ctx.strokeStyle='rgba(43,54,80,.55)'; ctx.beginPath(); ctx.moveTo(pad.l,y); ctx.lineTo(w-pad.r,y); ctx.stroke();
  }
  for (let i=0;i<=5;i++) {
    const xValue=minX+(maxX-minX)*i/5;
    const x=xFor(xValue);
    ctx.fillStyle='#95a2bd'; ctx.fillText(`${xValue.toFixed(2)}s`,x-14,h-12);
  }

  ctx.save();
  ctx.beginPath();
  ctx.rect(pad.l, pad.t, w-pad.l-pad.r, h-pad.t-pad.b);
  ctx.clip();

  ctx.strokeStyle = CHART_COLORS.eventTrace;
  ctx.lineWidth=1.5; ctx.setLineDash([]); ctx.beginPath();
  let started = false;
  xs.forEach((x,i) => {
    if (x < minX || x > maxX) { started = false; return; }
    const px=xFor(x), py=yFor(ys[i]);
    if (!started) { ctx.moveTo(px,py); started = true; }
    else ctx.lineTo(px,py);
  });
  ctx.stroke();

  ctx.strokeStyle='#ff6577'; ctx.setLineDash([5,4]); ctx.lineWidth=1.5;
  for (const marker of trace.markers || []) {
    const m=Number(marker);
    if (m < minX || m > maxX) continue;
    const x=xFor(m); ctx.beginPath(); ctx.moveTo(x,pad.t); ctx.lineTo(x,h-pad.b); ctx.stroke();
  }
  ctx.restore();
  ctx.setLineDash([]);
}

function updateChartTitles() {
  const hourly = selectedRange === '24h';
  document.getElementById('event-count-title').textContent = hourly ? 'Events/hour' : 'Events/day';
  document.getElementById('event-weight-title').textContent = hourly
    ? 'Avg. event weight (hourly)'
    : 'Avg. event weight (daily)';
}

async function loadCat() {
  updateChartTitles();
  const res = await fetch(`/api/cat/${encodeURIComponent(cat)}?range=${selectedRange}`, {cache:'no-store'});
  const data = await res.json();
  const s = data.series;

  drawMultiLine(document.getElementById('event-count'), s.labels, [
    {label:'Pee', values:s.pee_count, color:CHART_COLORS.pee},
    {label:'Poo', values:s.poo_count, color:CHART_COLORS.poo}
  ], {decimals:0, zeroBase:true});

  drawMultiLine(document.getElementById('event-weight'), s.labels, [
    {label:'Pee', values:s.pee_weight, color:CHART_COLORS.pee, connectGaps:true, drawPoints:true},
    {label:'Poo', values:s.poo_weight, color:CHART_COLORS.poo, connectGaps:true, drawPoints:true}
  ], {decimals:1, zeroBase:true});

  drawMultiLine(document.getElementById('cat-weight'), s.labels, [
    {label:'Weight', values:s.cat_weight, color:CHART_COLORS.weight}
  ], {decimals:0, showLegend:false});

  drawTrace(document.getElementById('poo-trace'), data.latest_traces.poo, 'poo');
  drawTrace(document.getElementById('pee-trace'), data.latest_traces.pee, 'pee');
  document.getElementById('poo-trace-meta').textContent = data.latest_traces.poo ? data.latest_traces.poo.ts : 'No poo event available';
  document.getElementById('pee-trace-meta').textContent = data.latest_traces.pee ? data.latest_traces.pee.ts : 'No pee event available';
}

document.querySelectorAll('#range-picker button').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('#range-picker button').forEach(x => x.classList.remove('active'));
    btn.classList.add('active');
    selectedRange = btn.dataset.range;
    updateChartTitles();
    loadCat().catch(console.error);
  });
});

document.querySelectorAll('[data-trace-action]').forEach(btn => {
  btn.addEventListener('click', () => {
    const canvas = document.getElementById(btn.dataset.target);
    if (!canvas) return;
    if (btn.dataset.traceAction === 'zoom-in') zoomTrace(canvas, 0.7);
    else if (btn.dataset.traceAction === 'zoom-out') zoomTrace(canvas, 1.4);
    else if (btn.dataset.traceAction === 'reset') resetTraceView(canvas);
  });
});

const dialog = document.getElementById('zero-dialog');
const confirmText = document.getElementById('confirm-text');
const confirmBtn = document.getElementById('confirm-zero');
const startDate = document.getElementById('start-date');

document.getElementById('zero-btn').addEventListener('click', () => dialog.showModal());
confirmText.addEventListener('input', () => { confirmBtn.disabled = confirmText.value.trim().toLowerCase() !== 'yes'; });
document.querySelectorAll('input[name="mode"]').forEach(r => r.addEventListener('change', () => {
  startDate.disabled = document.querySelector('input[name="mode"]:checked').value !== 'date';
}));

confirmBtn.addEventListener('click', async () => {
  const error = document.getElementById('zero-error'); error.textContent = '';
  const mode = document.querySelector('input[name="mode"]:checked').value;
  const payload = {confirm: confirmText.value, mode};
  if (mode === 'date') {
    if (!startDate.value) { error.textContent = 'Choose a start date.'; return; }
    payload.start_date = startDate.value;
  }
  confirmBtn.disabled = true;
  const res = await fetch(`/api/cat/${encodeURIComponent(cat)}/zero`, {
    method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload)
  });
  const data = await res.json();
  if (!res.ok) { error.textContent = data.error || 'Reset failed'; confirmBtn.disabled=false; return; }
  dialog.close(); confirmText.value=''; confirmBtn.disabled=true; await loadCat();
});

updateChartTitles();
loadCat().catch(console.error);
window.addEventListener('resize', () => loadCat().catch(console.error));
