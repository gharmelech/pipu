function fmtNumber(v, digits = 1) {
  if (v === null || v === undefined || Number.isNaN(v)) return '—';
  return Number(v).toFixed(digits);
}

function ageText(ts) {
  if (!ts) return 'never';
  const then = new Date(ts.replace(' ', 'T'));
  const sec = Math.max(0, (Date.now() - then.getTime()) / 1000);
  if (sec < 3600) return `${Math.floor(sec / 60)}m ago`;
  if (sec < 86400) return `${(sec / 3600).toFixed(1)}h ago`;
  return `${(sec / 86400).toFixed(1)}d ago`;
}

function trendHtml(metric) {
  const r = metric.readiness;
  if (!r.ready) return `<span class="trend accumulating">⚠ ${r.message}</span>`;
  const t = metric.trend;
  if (t.percent === null) return `<span class="trend good">→ baseline forming</span>`;
  return `<span class="trend ${t.level}">${t.direction} ${Math.abs(t.percent).toFixed(1)}%</span>`;
}

function metricBlock(label, value, suffix, metric) {
  return `
    <div class="metric">
      <div class="metric-line">
        <span class="metric-label">${label}</span>
        <span class="metric-value">${value}${suffix || ''}</span>
      </div>
      ${trendHtml(metric)}
    </div>`;
}



let carouselInitialized = false;
let carouselScrollTimer = null;
let carouselPointerStart = null;
let suppressNextCardClick = false;

function isPhoneCarousel() {
  return window.matchMedia('(max-width: 700px)').matches;
}

function nearestCardIndex(grid) {
  const cards = [...grid.querySelectorAll('.cat-card')];
  if (!cards.length) return 0;
  const gridRect = grid.getBoundingClientRect();
  const center = gridRect.left + gridRect.width / 2;
  let best = 0;
  let distance = Infinity;
  cards.forEach((card, i) => {
    const rect = card.getBoundingClientRect();
    const d = Math.abs((rect.left + rect.width / 2) - center);
    if (d < distance) { distance = d; best = i; }
  });
  return best;
}

function setActiveCarouselDot(index) {
  document.querySelectorAll('#cat-dots .carousel-dot').forEach((dot, i) => {
    dot.classList.toggle('active', i === index);
    dot.setAttribute('aria-current', i === index ? 'true' : 'false');
  });
}

function buildCarouselDots(preferredIndex = 0) {
  const grid = document.getElementById('cat-grid');
  const dots = document.getElementById('cat-dots');
  const cards = [...grid.querySelectorAll('.cat-card')];
  if (!dots) return;

  dots.innerHTML = cards.map((card, i) => {
    const name = card.querySelector('h2')?.textContent?.trim() || `cat ${i + 1}`;
    return `<button type="button" class="carousel-dot${i === 0 ? ' active' : ''}" data-index="${i}" aria-label="Show ${name}" aria-current="${i === 0 ? 'true' : 'false'}"></button>`;
  }).join('');

  dots.querySelectorAll('.carousel-dot').forEach(dot => {
    dot.addEventListener('click', () => {
      const card = cards[Number(dot.dataset.index)];
      if (!card) return;
      card.scrollIntoView({behavior: 'smooth', inline: 'center', block: 'nearest'});
      setActiveCarouselDot(Number(dot.dataset.index));
    });
  });

  if (!carouselInitialized) {
    carouselInitialized = true;

    grid.addEventListener('scroll', () => {
      if (!isPhoneCarousel()) return;
      clearTimeout(carouselScrollTimer);
      carouselScrollTimer = setTimeout(() => setActiveCarouselDot(nearestCardIndex(grid)), 50);
    }, {passive: true});

    grid.addEventListener('pointerdown', event => {
      if (!isPhoneCarousel()) return;
      carouselPointerStart = {x: event.clientX, y: event.clientY};
      suppressNextCardClick = false;
    }, {passive: true});

    grid.addEventListener('pointermove', event => {
      if (!carouselPointerStart || !isPhoneCarousel()) return;
      const dx = Math.abs(event.clientX - carouselPointerStart.x);
      const dy = Math.abs(event.clientY - carouselPointerStart.y);
      if (dx > 10 && dx > dy) suppressNextCardClick = true;
    }, {passive: true});

    const endPointerGesture = () => {
      carouselPointerStart = null;
      setTimeout(() => { suppressNextCardClick = false; }, 0);
    };
    grid.addEventListener('pointerup', endPointerGesture, {passive: true});
    grid.addEventListener('pointercancel', endPointerGesture, {passive: true});

    grid.addEventListener('click', event => {
      if (suppressNextCardClick && event.target.closest('.cat-card')) {
        event.preventDefault();
        event.stopPropagation();
      }
    }, true);

    window.addEventListener('resize', () => {
      if (isPhoneCarousel()) setActiveCarouselDot(nearestCardIndex(grid));
      else setActiveCarouselDot(0);
    }, {passive: true});
  }

  if (isPhoneCarousel()) {
    requestAnimationFrame(() => {
      const index = Math.max(0, Math.min(Number(preferredIndex) || 0, cards.length - 1));
      const card = cards[index];
      if (card) {
        grid.scrollLeft = Math.max(0, card.offsetLeft - (grid.clientWidth - card.offsetWidth) / 2);
      }
      setActiveCarouselDot(index);
    });
  }
}

async function loadDashboard() {
  const res = await fetch('/api/dashboard', {cache: 'no-store'});
  const data = await res.json();
  const grid = document.getElementById('cat-grid');
  const carouselIndex = isPhoneCarousel() ? nearestCardIndex(grid) : 0;

  grid.innerHTML = data.cats.map(cat => {
    const m = cat.metrics;
    return `
      <a class="cat-card" href="/cat/${encodeURIComponent(cat.name)}">
        <div class="card-head"><h2>${cat.name}</h2><span>›</span></div>
        ${metricBlock('Weight', fmtNumber(m.cat_weight.value / 1000, 2), ' kg', m.cat_weight)}
        ${metricBlock('Poos / day', fmtNumber(m.poo_count.value, 2), '', m.poo_count)}
        ${metricBlock('Avg. poo weight', fmtNumber(m.poo_weight.value, 1), ' g', m.poo_weight)}
        ${metricBlock('Pees / day', fmtNumber(m.pee_count.value, 2), '', m.pee_count)}
        ${metricBlock('Avg. pee weight', fmtNumber(m.pee_weight.value, 1), ' g', m.pee_weight)}
        <div class="last-row"><span>Last poo</span><strong>${ageText(cat.last.poo)}</strong></div>
        <div class="last-row"><span>Last pee</span><strong>${ageText(cat.last.pee)}</strong></div>
        <div class="rejected">
          Rejected 24h: ${cat.rejected['24h'].cat_weight} body / ${cat.rejected['24h'].pee_weight} pee / ${cat.rejected['24h'].poo_weight} poo ·
          7d: ${cat.rejected.week.cat_weight} / ${cat.rejected.week.pee_weight} / ${cat.rejected.week.poo_weight} ·
          30d: ${cat.rejected.month.cat_weight} / ${cat.rejected.month.pee_weight} / ${cat.rejected.month.poo_weight}
        </div>
      </a>`;
  }).join('');

  buildCarouselDots(carouselIndex);

  const u = data.unattributed;
  const reasons = Object.entries(u.reasons_30d || {}).map(([k,v]) => `${k.replaceAll('_',' ')}: ${v}`).join(' · ') || 'None';
  document.getElementById('unattributed').innerHTML = `
    <section class="unattributed-card">
      <div class="card-head"><h2>Unattributed events</h2><span class="muted">Could not be safely associated with a cat</span></div>
      <div class="unattributed-grid">
        <div><div class="metric-label">Last 24h</div><div class="big-number">${u.counts['24h']}</div></div>
        <div><div class="metric-label">Last 7d</div><div class="big-number">${u.counts.week}</div></div>
        <div><div class="metric-label">Last 30d</div><div class="big-number">${u.counts.month}</div></div>
      </div>
      <p class="muted unattributed-reasons">30-day reasons · ${reasons}</p>
    </section>`;

  document.getElementById('updated').textContent = `Updated ${new Date().toLocaleTimeString()}`;
}

loadDashboard().catch(console.error);
setInterval(() => loadDashboard().catch(console.error), 30000);
