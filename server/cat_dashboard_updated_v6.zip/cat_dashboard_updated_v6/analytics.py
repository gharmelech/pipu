import ast
import hashlib
import json
import math
import os
import statistics
import threading
import time
from collections import defaultdict
from datetime import datetime, timedelta

import config
import db

_SYNC_LOCK = threading.Lock()
_LAST_SYNC_MONOTONIC = 0.0


def now_local():
    return datetime.now()


def dt_to_str(value):
    return value.strftime('%Y-%m-%d %H:%M:%S')


def parse_dt(value):
    if isinstance(value, datetime):
        return value
    return datetime.strptime(value, '%Y-%m-%d %H:%M:%S')


def normalize_cat_id(raw):
    if raw is None:
        return None
    text = str(raw).strip()
    if not text:
        return None
    return config.CAT_ALIASES.get(text.lower())


def parse_log_line(line):
    try:
        brace = line.find('{')
        if brace < 0:
            return None
        ts = datetime.strptime(line[:brace].strip(), '%Y-%m-%d %H:%M:%S')
        event = ast.literal_eval(line[brace:].strip())
        if not isinstance(event, dict):
            return None
        return ts, event
    except Exception:
        return None


def event_hash(ts, event):
    # repr is deterministic enough for these primitive log dictionaries and preserves sample order.
    payload = dt_to_str(ts) + '|' + repr(event)
    return hashlib.sha256(payload.encode('utf-8', errors='replace')).hexdigest()


def numeric(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(float(value))


def cleaned_trace(samples):
    clean_x = []
    clean_y = []
    markers = []
    for i, sample in enumerate(samples or []):
        t = i * config.SAMPLE_INTERVAL_SEC
        if sample == config.MARKER_VALUE:
            markers.append(max(0.0, t - config.MARKER_SHIFT_SEC))
            continue
        if numeric(sample):
            clean_x.append(t)
            clean_y.append(float(sample))
    return clean_x, clean_y, markers


def duration_from_samples(samples):
    valid = sum(1 for x in (samples or []) if x != config.MARKER_VALUE)
    return max(0.0, valid * config.SAMPLE_INTERVAL_SEC - config.DEPOSIT_TIME_OFFSET_SEC)


def robust_outlier(value, history):
    if not numeric(value):
        return True
    vals = [float(v) for v in history if numeric(v)]
    if len(vals) < config.OUTLIER_MIN_POINTS:
        return False

    med = statistics.median(vals)
    deviations = [abs(v - med) for v in vals]
    mad = statistics.median(deviations)

    if mad > 0:
        score = 0.6745 * abs(float(value) - med) / mad
        return score > config.OUTLIER_MAD_Z

    # A flat history produces MAD=0. Use a small percentage envelope rather than
    # declaring all future non-identical measurements as outliers.
    tolerance = max(1.0, abs(med) * config.OUTLIER_ZERO_MAD_PERCENT / 100.0)
    return abs(float(value) - med) > tolerance


def get_cat_state(conn, cat):
    return conn.execute('SELECT * FROM cat_state WHERE cat=?', (cat,)).fetchone()


def _recent_cat_weights(conn, cat, before_ts=None):
    cutoff = now_local() - timedelta(days=config.ADAPTIVE_WEIGHT_LOOKBACK_DAYS)
    params = [cat, dt_to_str(cutoff)]
    sql = '''
        SELECT cat_weight FROM events
        WHERE cat=? AND ts>=? AND cat_weight IS NOT NULL AND cat_weight_outlier=0
    '''
    if before_ts is not None:
        sql += ' AND ts<?'
        params.append(dt_to_str(before_ts))
    sql += ' ORDER BY ts DESC LIMIT ?'
    params.append(config.ADAPTIVE_WEIGHT_MAX_POINTS)
    return [r['cat_weight'] for r in conn.execute(sql, params).fetchall()]


def _deposit_history(conn, cat, kind, before_ts=None):
    cutoff = now_local() - timedelta(days=config.TREND_BASELINE_DAYS)
    params = [cat, kind, dt_to_str(cutoff)]
    sql = '''
        SELECT deposit_weight FROM events
        WHERE cat=? AND event_kind=? AND ts>=?
          AND deposit_weight IS NOT NULL AND deposit_weight_outlier=0
    '''
    if before_ts is not None:
        sql += ' AND ts<?'
        params.append(dt_to_str(before_ts))
    sql += ' ORDER BY ts DESC LIMIT 200'
    return [r['deposit_weight'] for r in conn.execute(sql, params).fetchall()]


def expected_weight(conn, cat):
    state = get_cat_state(conn, cat)
    recent = _recent_cat_weights(conn, cat)
    if recent:
        return float(statistics.median(recent))
    return float(state['adaptive_weight'] if state else config.BOOTSTRAP_WEIGHT_G[cat])


def update_adaptive_weight(conn, cat):
    recent = _recent_cat_weights(conn, cat)
    if recent:
        adaptive = float(statistics.median(recent))
        conn.execute(
            'UPDATE cat_state SET adaptive_weight=?, updated_at=? WHERE cat=?',
            (adaptive, dt_to_str(now_local()), cat),
        )


def attribute_event(conn, event):
    raw_cat = event.get('Cat ID')
    normalized = normalize_cat_id(raw_cat)

    if raw_cat is None or str(raw_cat).strip() == '':
        candidate = 'Pini'
    elif normalized:
        candidate = normalized
    else:
        return None, None, 'unknown_cat_id'

    weight = event.get('Cat Weight')
    if not numeric(weight) or float(weight) <= 0:
        return None, candidate, 'missing_or_invalid_weight'

    expected = expected_weight(conn, candidate)
    tol = max(
        expected * config.ATTRIBUTION_WEIGHT_TOLERANCE_PERCENT / 100.0,
        config.ATTRIBUTION_WEIGHT_TOLERANCE_MIN_G,
    )

    if abs(float(weight) - expected) > tol:
        return None, candidate, 'weight_outside_tolerance'

    return candidate, candidate, None


def process_event(ts, event, conn=None):
    own_conn = conn is None
    if own_conn:
        context = db.connect()
        conn = context.__enter__()

    try:
        type_value = str(event.get('Type', ''))
        if type_value not in config.EVENT_TYPE_MAP:
            return False

        ev_hash = event_hash(ts, event)
        if conn.execute('SELECT 1 FROM events WHERE event_hash=?', (ev_hash,)).fetchone():
            return False

        kind = config.EVENT_TYPE_MAP[type_value]
        attributed_cat, candidate_cat, reject_reason = attribute_event(conn, event)

        # A manual statistics reset establishes a persistent lower time bound for
        # that cat. This prevents a later log truncate/rewrite rescan from
        # resurrecting older events that the user intentionally zeroed away.
        if candidate_cat:
            candidate_state = get_cat_state(conn, candidate_cat)
            if candidate_state and candidate_state['stats_start'] and ts < parse_dt(candidate_state['stats_start']):
                return False

        raw_cat = event.get('Cat ID')
        cat_weight = float(event['Cat Weight']) if numeric(event.get('Cat Weight')) else None
        dep = float(event['Deposit Weight']) if numeric(event.get('Deposit Weight')) else None
        if dep is not None and config.DEPOSIT_WEIGHT_ABSOLUTE:
            dep = abs(dep)

        samples = event.get('Samples') if isinstance(event.get('Samples'), list) else []
        duration = duration_from_samples(samples)

        cat_weight_outlier = 0
        deposit_weight_outlier = 0

        if attributed_cat:
            weight_history = _recent_cat_weights(conn, attributed_cat, before_ts=ts)
            cat_weight_outlier = int(robust_outlier(cat_weight, weight_history)) if cat_weight is not None else 1

            dep_history = _deposit_history(conn, attributed_cat, kind, before_ts=ts)
            deposit_weight_outlier = int(robust_outlier(dep, dep_history)) if dep is not None else 1

        status = 'attributed' if attributed_cat else 'unattributed'

        conn.execute(
            '''
            INSERT INTO events(
                event_hash, ts, raw_cat_id, candidate_cat, cat, event_kind,
                cat_weight, deposit_weight, duration_sec,
                cat_weight_outlier, deposit_weight_outlier,
                attribution_status, reject_reason
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''',
            (
                ev_hash, dt_to_str(ts), None if raw_cat is None else str(raw_cat),
                candidate_cat, attributed_cat, kind, cat_weight, dep, duration,
                cat_weight_outlier, deposit_weight_outlier, status, reject_reason,
            ),
        )

        if attributed_cat:
            clean_x, clean_y, markers = cleaned_trace(samples)
            trace_payload = {'x': clean_x, 'y': clean_y}
            existing = conn.execute(
                'SELECT ts FROM latest_traces WHERE cat=? AND event_kind=?',
                (attributed_cat, kind),
            ).fetchone()
            if existing is None or ts >= parse_dt(existing['ts']):
                conn.execute(
                    '''
                    INSERT INTO latest_traces(cat, event_kind, ts, samples_json, marker_times_json)
                    VALUES (?, ?, ?, ?, ?)
                    ON CONFLICT(cat, event_kind) DO UPDATE SET
                        ts=excluded.ts,
                        samples_json=excluded.samples_json,
                        marker_times_json=excluded.marker_times_json
                    ''',
                    (
                        attributed_cat, kind, dt_to_str(ts),
                        db.json_dumps(trace_payload), db.json_dumps(markers),
                    ),
                )

            if not cat_weight_outlier:
                update_adaptive_weight(conn, attributed_cat)

            state = get_cat_state(conn, attributed_cat)
            if state and not state['stats_start']:
                conn.execute(
                    'UPDATE cat_state SET stats_start=? WHERE cat=?',
                    (dt_to_str(ts), attributed_cat),
                )

        return True
    finally:
        if own_conn:
            context.__exit__(None, None, None)


def sync_log(force=False):
    global _LAST_SYNC_MONOTONIC

    now_mono = time.monotonic()
    if not force and now_mono - _LAST_SYNC_MONOTONIC < config.LOG_SYNC_MIN_INTERVAL_SEC:
        return

    if not config.LOG_FILE.exists():
        _LAST_SYNC_MONOTONIC = now_mono
        return

    with _SYNC_LOCK:
        stat = config.LOG_FILE.stat()
        with db.connect() as conn:
            state = conn.execute('SELECT * FROM log_state WHERE id=1').fetchone()
            offset = int(state['offset'] or 0)
            generation = int(state['generation'] or 0)

            replaced = (
                state['device'] is not None and
                (int(state['device']) != int(stat.st_dev) or int(state['inode']) != int(stat.st_ino))
            )
            truncated = stat.st_size < offset

            # Detect an in-place truncate/rewrite even when the rewritten file has
            # already grown past the old offset. We persist a hash of the bytes
            # immediately before the last processed offset and verify that anchor.
            anchor_changed = False
            if not replaced and not truncated and offset > 0 and state['anchor_hash']:
                anchor_start = int(state['anchor_start'] or 0)
                anchor_len = offset - anchor_start
                if anchor_len > 0 and stat.st_size >= offset:
                    with open(config.LOG_FILE, 'rb') as af:
                        af.seek(anchor_start)
                        current_anchor = af.read(anchor_len)
                    current_hash = hashlib.sha256(current_anchor).hexdigest()
                    anchor_changed = current_hash != state['anchor_hash']

            if replaced or truncated or anchor_changed:
                offset = 0
                generation += 1

            with open(config.LOG_FILE, 'r', encoding='utf-8', errors='replace') as f:
                f.seek(offset)
                for line in f:
                    parsed = parse_log_line(line)
                    if parsed:
                        ts, event = parsed
                        process_event(ts, event, conn=conn)
                offset = f.tell()

            # Create a new 256-byte anchor ending at the processed offset.
            anchor_start = max(0, offset - 256)
            with open(config.LOG_FILE, 'rb') as af:
                af.seek(anchor_start)
                anchor_bytes = af.read(max(0, offset - anchor_start))
            anchor_hash = hashlib.sha256(anchor_bytes).hexdigest() if anchor_bytes else None
            final_size = config.LOG_FILE.stat().st_size

            conn.execute(
                '''
                UPDATE log_state
                SET device=?, inode=?, offset=?, size=?, generation=?, last_sync=?,
                    anchor_start=?, anchor_hash=?
                WHERE id=1
                ''',
                (
                    int(stat.st_dev), int(stat.st_ino), offset, int(final_size), generation,
                    dt_to_str(now_local()), anchor_start, anchor_hash,
                ),
            )

        _LAST_SYNC_MONOTONIC = time.monotonic()


def append_log_event(event):
    config.LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    ts = now_local()
    with open(config.LOG_FILE, 'a', encoding='utf-8') as f:
        f.write(f'{dt_to_str(ts)} {repr(event)}\n')
        f.flush()
        os.fsync(f.fileno())
    with db.connect() as conn:
        process_event(ts, event, conn=conn)
    return ts


def _range_start(range_name, now):
    if range_name == '24h':
        return now - timedelta(hours=24)
    if range_name == 'week':
        return now - timedelta(days=7)
    if range_name == 'month':
        return now - timedelta(days=30)
    return None


def _severity(metric, pct):
    if pct is None:
        return {'direction': '→', 'percent': None, 'level': 'unknown'}
    thresholds = config.TREND_THRESHOLDS[metric]
    apct = abs(pct)
    direction = '→' if apct <= thresholds['stable'] else ('↑' if pct > 0 else '↓')
    if apct >= thresholds['critical']:
        level = 'critical'
    elif apct >= thresholds['warning']:
        level = 'warning'
    else:
        level = 'good'
    return {'direction': direction, 'percent': round(pct, 1), 'level': level}


def _readiness(state_start, valid_points, metric, now):
    if state_start:
        start = parse_dt(state_start)
        elapsed_days = max(0.0, (now - start).total_seconds() / 86400.0)
    else:
        elapsed_days = 0.0
    days_left = max(0, int(math.ceil(config.FULL_STATS_DAYS - elapsed_days)))
    points_left = max(0, int(config.MIN_POINTS[metric] - valid_points))
    ready = days_left == 0 and points_left == 0

    if ready:
        return {'ready': True, 'message': None}
    if days_left and points_left:
        msg = f'Accumulating data — full stats in ~{days_left} days and at least {points_left} more valid measurements'
    elif days_left:
        msg = f'Accumulating data — full stats in ~{days_left} days'
    else:
        msg = f'Accumulating data — need {points_left} more valid measurements'
    return {'ready': False, 'message': msg}


def _mean(values):
    vals = [float(v) for v in values if numeric(v)]
    return statistics.mean(vals) if vals else None


def _metric_trend(conn, cat, metric, now, stats_start=None):
    recent_start = now - timedelta(days=config.TREND_RECENT_DAYS)
    baseline_start = now - timedelta(days=config.TREND_BASELINE_DAYS)

    if metric == 'cat_weight':
        recent = [r['cat_weight'] for r in conn.execute(
            '''SELECT cat_weight FROM events WHERE cat=? AND ts>=? AND cat_weight IS NOT NULL AND cat_weight_outlier=0''',
            (cat, dt_to_str(recent_start)),
        )]
        baseline = [r['cat_weight'] for r in conn.execute(
            '''SELECT cat_weight FROM events WHERE cat=? AND ts>=? AND ts<? AND cat_weight IS NOT NULL AND cat_weight_outlier=0''',
            (cat, dt_to_str(baseline_start), dt_to_str(recent_start)),
        )]
        current = _mean(recent)
        base = _mean(baseline)
        points = len(recent) + len(baseline)
    elif metric in ('pee_weight', 'poo_weight'):
        kind = metric.split('_')[0]
        recent = [r['deposit_weight'] for r in conn.execute(
            '''SELECT deposit_weight FROM events WHERE cat=? AND event_kind=? AND ts>=? AND deposit_weight IS NOT NULL AND deposit_weight_outlier=0''',
            (cat, kind, dt_to_str(recent_start)),
        )]
        baseline = [r['deposit_weight'] for r in conn.execute(
            '''SELECT deposit_weight FROM events WHERE cat=? AND event_kind=? AND ts>=? AND ts<? AND deposit_weight IS NOT NULL AND deposit_weight_outlier=0''',
            (cat, kind, dt_to_str(baseline_start), dt_to_str(recent_start)),
        )]
        current = _mean(recent)
        base = _mean(baseline)
        points = len(recent) + len(baseline)
    else:
        kind = metric.split('_')[0]
        state_start = parse_dt(stats_start) if stats_start else None
        effective_recent_start = max(recent_start, state_start) if state_start else recent_start
        recent_count = conn.execute(
            'SELECT COUNT(*) AS n FROM events WHERE cat=? AND event_kind=? AND ts>=?',
            (cat, kind, dt_to_str(effective_recent_start)),
        ).fetchone()['n']
        available_recent_days = max(1.0, (now - effective_recent_start).total_seconds() / 86400.0)
        current = recent_count / available_recent_days

        effective_baseline_start = max(baseline_start, state_start) if state_start else baseline_start
        if effective_baseline_start < recent_start:
            base_count = conn.execute(
                'SELECT COUNT(*) AS n FROM events WHERE cat=? AND event_kind=? AND ts>=? AND ts<?',
                (cat, kind, dt_to_str(effective_baseline_start), dt_to_str(recent_start)),
            ).fetchone()['n']
            baseline_days = max(1.0, (recent_start - effective_baseline_start).total_seconds() / 86400.0)
            base = base_count / baseline_days
        else:
            base_count = 0
            base = None
        points = recent_count + base_count

    pct = None
    if current is not None and base is not None and abs(base) > 1e-9:
        pct = (current - base) / abs(base) * 100.0
    return current, base, points, _severity(metric, pct)


def dashboard_summary():
    sync_log()
    now = now_local()
    result = {'cats': [], 'unattributed': {}}

    with db.connect() as conn:
        for cat in config.CATS:
            state = get_cat_state(conn, cat)
            metrics = {}
            for metric in ('cat_weight', 'poo_count', 'poo_weight', 'pee_count', 'pee_weight'):
                current, baseline, points, trend = _metric_trend(
                    conn, cat, metric, now, state['stats_start'] if state else None
                )
                readiness = _readiness(state['stats_start'] if state else None, points, metric, now)
                if not readiness['ready']:
                    trend = {'direction': None, 'percent': None, 'level': 'accumulating'}
                metrics[metric] = {
                    'value': None if current is None else round(current, 2),
                    'baseline': None if baseline is None else round(baseline, 2),
                    'points': points,
                    'trend': trend,
                    'readiness': readiness,
                }

            last = {}
            for kind in ('pee', 'poo'):
                row = conn.execute(
                    'SELECT ts FROM events WHERE cat=? AND event_kind=? ORDER BY ts DESC LIMIT 1',
                    (cat, kind),
                ).fetchone()
                last[kind] = row['ts'] if row else None

            rejected = {}
            for label, delta in (('24h', timedelta(hours=24)), ('week', timedelta(days=7)), ('month', timedelta(days=30))):
                since = dt_to_str(now - delta)
                rejected[label] = {
                    'cat_weight': conn.execute(
                        '''SELECT COUNT(*) AS n FROM events WHERE candidate_cat=? AND ts>=? AND (cat_weight_outlier=1 OR reject_reason='weight_outside_tolerance')''',
                        (cat, since),
                    ).fetchone()['n'],
                    'pee_weight': conn.execute(
                        '''SELECT COUNT(*) AS n FROM events WHERE cat=? AND event_kind='pee' AND ts>=? AND deposit_weight_outlier=1''',
                        (cat, since),
                    ).fetchone()['n'],
                    'poo_weight': conn.execute(
                        '''SELECT COUNT(*) AS n FROM events WHERE cat=? AND event_kind='poo' AND ts>=? AND deposit_weight_outlier=1''',
                        (cat, since),
                    ).fetchone()['n'],
                }

            result['cats'].append({
                'name': cat,
                'adaptive_weight': round(float(state['adaptive_weight']), 1) if state else None,
                'stats_start': state['stats_start'] if state else None,
                'metrics': metrics,
                'last': last,
                'rejected': rejected,
            })

        unattributed = {}
        for label, delta in (('24h', timedelta(hours=24)), ('week', timedelta(days=7)), ('month', timedelta(days=30))):
            since = dt_to_str(now - delta)
            unattributed[label] = conn.execute(
                'SELECT COUNT(*) AS n FROM events WHERE attribution_status=? AND ts>=?',
                ('unattributed', since),
            ).fetchone()['n']
        reasons = {
            r['reject_reason'] or 'unknown': r['n']
            for r in conn.execute(
                '''SELECT reject_reason, COUNT(*) AS n FROM events
                   WHERE attribution_status='unattributed' AND ts>=?
                   GROUP BY reject_reason''',
                (dt_to_str(now - timedelta(days=30)),),
            ).fetchall()
        }
        result['unattributed'] = {'counts': unattributed, 'reasons_30d': reasons}

    return result


def cat_series(cat, range_name):
    sync_log()
    now = now_local()
    start = _range_start(range_name, now)

    with db.connect() as conn:
        params = [cat]
        sql = 'SELECT * FROM events WHERE cat=?'
        if start:
            sql += ' AND ts>=?'
            params.append(dt_to_str(start))
        sql += ' ORDER BY ts'
        rows = conn.execute(sql, params).fetchall()

        hourly = range_name == '24h'
        buckets = defaultdict(lambda: {
            'pee_count': 0, 'poo_count': 0,
            'pee_weights': [], 'poo_weights': [], 'cat_weights': []
        })

        for r in rows:
            ts = parse_dt(r['ts'])
            key = ts.strftime('%Y-%m-%d %H:00') if hourly else ts.strftime('%Y-%m-%d')
            b = buckets[key]
            kind = r['event_kind']
            if kind in ('pee', 'poo'):
                b[kind + '_count'] += 1
                if r['deposit_weight'] is not None and not r['deposit_weight_outlier']:
                    b[kind + '_weights'].append(r['deposit_weight'])
            if r['cat_weight'] is not None and not r['cat_weight_outlier']:
                b['cat_weights'].append(r['cat_weight'])

        labels = sorted(buckets.keys())
        series = {
            'labels': labels,
            'pee_count': [], 'poo_count': [],
            'pee_weight': [], 'poo_weight': [], 'cat_weight': [],
        }
        for key in labels:
            b = buckets[key]
            series['pee_count'].append(b['pee_count'])
            series['poo_count'].append(b['poo_count'])
            series['pee_weight'].append(_mean(b['pee_weights']))
            series['poo_weight'].append(_mean(b['poo_weights']))
            series['cat_weight'].append(_mean(b['cat_weights']))

        traces = {}
        for kind in ('pee', 'poo'):
            row = conn.execute(
                'SELECT * FROM latest_traces WHERE cat=? AND event_kind=?',
                (cat, kind),
            ).fetchone()
            if row:
                payload = json.loads(row['samples_json'])
                traces[kind] = {
                    'ts': row['ts'],
                    'x': payload['x'],
                    'y': payload['y'],
                    'markers': json.loads(row['marker_times_json']),
                }
            else:
                traces[kind] = None

        state = get_cat_state(conn, cat)

    return {
        'cat': cat,
        'range': range_name,
        'stats_start': state['stats_start'] if state else None,
        'series': series,
        'latest_traces': traces,
    }


def find_log_start():
    if not config.LOG_FILE.exists():
        return None
    with open(config.LOG_FILE, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            parsed = parse_log_line(line)
            if parsed:
                return parsed[0]
    return None


def rebuild_cat(cat, mode, requested_start=None):
    if cat not in config.CATS:
        raise ValueError('Unknown cat')
    if mode not in ('log_start', 'date', 'now'):
        raise ValueError('Invalid reset mode')

    current = now_local()
    log_start = find_log_start()

    if mode == 'now':
        effective = current
    elif mode == 'log_start':
        if log_start is None:
            effective = current
        else:
            effective = log_start
    else:
        if not requested_start:
            raise ValueError('start_date is required')
        try:
            requested = datetime.fromisoformat(requested_start)
        except ValueError:
            raise ValueError('start_date must be ISO format')
        effective = max(requested, log_start) if log_start else requested

    with db.connect() as conn:
        # Clear attributed history plus unattributed candidate events for this cat so
        # the adaptive attribution can be rebuilt cleanly from the selected raw-log window.
        conn.execute('DELETE FROM events WHERE cat=? OR (cat IS NULL AND candidate_cat=?)', (cat, cat))
        conn.execute('DELETE FROM latest_traces WHERE cat=?', (cat,))
        bootstrap = float(config.BOOTSTRAP_WEIGHT_G[cat])
        conn.execute(
            '''UPDATE cat_state SET adaptive_weight=?, stats_start=?, updated_at=? WHERE cat=?''',
            (bootstrap, dt_to_str(effective), dt_to_str(current), cat),
        )
        conn.execute(
            '''INSERT INTO reset_audit(ts, cat, mode, requested_start, effective_start, note)
               VALUES (?, ?, ?, ?, ?, ?)''',
            (
                dt_to_str(current), cat, mode, requested_start,
                dt_to_str(effective), 'Statistics rebuilt from available raw log',
            ),
        )

        if mode != 'now' and config.LOG_FILE.exists():
            with open(config.LOG_FILE, 'r', encoding='utf-8', errors='replace') as f:
                for line in f:
                    parsed = parse_log_line(line)
                    if not parsed:
                        continue
                    ts, event = parsed
                    if ts < effective:
                        continue
                    raw = event.get('Cat ID')
                    normalized = normalize_cat_id(raw)
                    candidate = 'Pini' if raw is None or str(raw).strip() == '' else normalized
                    if candidate == cat:
                        process_event(ts, event, conn=conn)

    return {
        'cat': cat,
        'mode': mode,
        'requested_start': requested_start,
        'effective_start': dt_to_str(effective),
        'log_start': dt_to_str(log_start) if log_start else None,
    }
